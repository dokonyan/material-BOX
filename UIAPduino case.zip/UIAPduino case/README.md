This case is designed specifically for the UIAPduino.
このケースは、UIAPduino専用に設計されています。